#!/bin/bash
rm posi-neb
for n in `seq 127`
do
  sed -n "$n"p posi.neb1 >> posi-neb
  sed -n "$n"p posi.neb2 >> posi-neb
  sed -n "$n"p posi.neb3 >> posi-neb
  sed -n "$n"p posi.neb4 >> posi-neb
  sed -n "$n"p posi.neb5 >> posi-neb
  sed -n "$n"p posi.neb6 >> posi-neb
  sed -n "$n"p posi.neb7 >> posi-neb
  sed -n "$n"p posi.neb8 >> posi-neb
  echo " " >> posi-neb
done
