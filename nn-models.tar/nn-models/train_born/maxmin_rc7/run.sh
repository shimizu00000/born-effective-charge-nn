#!bin/sh
./a.out > log.dat
cp -r ./data_maxmin ..
