#!/bin/bash
cp ../maxmin_rc7/data_maxmin/g* .
  
