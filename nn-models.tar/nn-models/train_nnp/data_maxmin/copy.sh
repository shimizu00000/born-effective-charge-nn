#!/bin/bash
cp ../maxmin_sf/data_maxmin/g* .
  
